/**
 * Created by liuyujing on 2017/2/7.
 */
(function () {

    var app = angular.module("app",[]);
    app.controller("homeController",function ($scope) {
        $scope.name = "小明";
    });

    app.controller("findController",function ($scope) {

    });

})();
