/**
 * Created by liuyujing on 2017/2/7.
 */

(function () {

    //通过angular 中的 module函数 定义模块
    //参数  1.模块的名字 2.空数组 以后可以注入服务
    var app = angular.module("app",[]);

})();
