/**
 * Created by liuyujing on 2017/1/6.
 */
(function () {

    function init() {
        new Map();
    }

    init();

})();