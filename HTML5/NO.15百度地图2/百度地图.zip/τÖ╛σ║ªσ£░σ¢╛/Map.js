/**
 * Created by liuyujing on 2017/1/6.
 */
(function () {

    function Map() {
        this.showMap();
        this.addEventListener();
    }

    Map.prototype.showMap = function () {
        this.map = new BMap.Map("map", {minZoom: 3});

        this.moveToCurrentPosition();
    };

    Map.prototype.moveToCurrentPosition = function () {

        navigator.geolocation.getCurrentPosition(function (loc) {
            this.map.centerAndZoom(new BMap.Point(loc.coords.latitude, loc.coords.longitude), 5);

        }.bind(this));

    };

    Map.prototype.addEventListener = function () {

        this.map.addEventListener("click", function (event) {
            //type, target, point, pixel, overlay
            console.log(event.overlay);

            /*
            var marker = new BMap.Marker(event.point);

            //开启大头针拖拽的功能
            marker.enableDragging();
            event.target.addOverlay(marker);
            //给大头针 添加动画
            marker.setAnimation(BMAP_ANIMATION_DROP);

            marker.addEventListener("dragend", function (event) {
                console.log(event.point);
            })
            */

            new Marker(event.target).addMarker(event.point);

        });

        //右键双击事件
        this.map.addEventListener("rightdblclick", function (event) {
            //清除地图上的所有 覆盖物
            event.target.clearOverlays();
        });

        //地图的右键事件
        this.map.addEventListener("rightclick", function (event) {
            //移除覆盖物
            event.target.removeOverlay(event.overlay);
        });
    };

    window.Map = Map;

})();